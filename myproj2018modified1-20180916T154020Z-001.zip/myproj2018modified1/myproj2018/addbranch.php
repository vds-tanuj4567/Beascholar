<?php
session_start();
?>
<?php
$x=$_GET["bname"];
$y=$_GET["bid"];
$conn=new mysqli("localhost:3306","root","tanuj","test");
if($conn->connect_error)
{
    die("connect:failed");
}
 else {

     $sql="insert into branch values(".$y.",'".$x."')";
     if($conn->query($sql))
     {
         echo"<center>values inserted successfully</center>";
         include('addbranch.html');
     }
     
}
?>


