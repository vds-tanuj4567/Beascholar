<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1> File Handling in C</h1><br>

File Handling in c language is used to open, read, write, search or close file. <br>It is used for permanent storage.<br>
Advantage of File<br>

It will contain the data even after program exit.<br> Normally we use variable or array to store data, but data is lost after program exit. <br>Variables and arrays are non-permanent storage medium whereas file is permanent storage medium.<br>
Functions for file handling<br>

There are many functions in C library to open, read, write, search and close file. A list of file functions are given below:<br>
<img src="filehandling.jpeg" width="30%">
<h2>modes of opening a file:</h2>
<img src="modes.png" width="30%">
<h1>Command line Arguments</h1>
The arguments passed from command line are called command line arguments. These arguments are handled by main() function.
<br>
To support command line argument, you need to change the structure of main() function as given below.
<br>
    int main(int argc, char *argv[] )  <br>

Here, argc counts the number of arguments. It counts the file name as the first argument.<br>

The argv[] contains the total number of arguments. The first argument is the file name always.<br>
<h1>Pre Processor :</h1><br>
The C preprocessor is a micro processor that is used by compiler to transform your code before compilation.<br> It is called micro preprocessor because it allows us to add macros.
Note: Proprocessor direcives are executed before compilation.<br>
<h2>List of C preprocessor directives:</h2><br>

All preprocessor directives starts with hash # symbol.
<br>
Let's see a list of preprocessor directives.
<br>
   1. #include<br>
    2.#define<br>
    3.#undef<br>
    4.#ifdef<br>
    5.#ifndef<br>
    6.#if<br>
    7.#else<br>
    8.#elif<br>
    9.#endif<br>
    10.#error<br>
    11.#pragma<br>
    <img src="preprocessor.jpeg" width="50%">
<form method="GET" action="cp2.php">
<input type="submit" value="End the Course">
</form>
    </body>
</html>


