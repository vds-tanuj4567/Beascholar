
<?php
session_start();
?>
<html>
    <head>
<style>
body
{
background-image: url("e5.jpg");
color:yellow;
font-size:30px;

}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:yellow;
}
</style>
</head>
<body>
        <?php
$x="";
$c=1;
if(!empty($_GET["branch"]))
{
    foreach($_GET["branch"] as $e)
    {
        $x=$x.$e;
    }
}
$conn=new mysqli("localhost:3306","root","tanuj","test");
 
 $sql="select cname from course where brid=(select bid from branch where bname='".$x."')";
 $res=$conn->query($sql);
 echo"<center>";
 echo"<table border=2>";
 
 if($res->num_rows)
 {
     while($row=$res->fetch_assoc())
     {echo"<tr>";
    /* if($x=='CSE')
     {
            if($c==1)
            {
                echo "<td><img src='c.png'>";
                echo "<td ><a href='cp.php' class='p1'>$row[cname]</a></td>";
                
            }
            if($c==2)
            {
                echo "<td><img src='ds.jpeg'>";
                echo "<td ><a href='' class='p1'>$row[cname]</a></td>";
                
            }
            if($c==3)
            {
                echo "<td><img src='java.png'>";
                echo "<td ><a href='' class='p1'>$row[cname]</a></td>";
                
            }
            if($c==4)
            {
                echo "<td><img src='dbms.jpeg'>";
                echo "<td ><a href='' class='p1'>$row[cname]</a></td>";
                
            }
            if($c>=5)
            {
                echo "<td></td>";
                echo "<td ><a href='' class='p1'>$row[cname]</a></td>";
            }
            $c=$c+1;
     }*/
        
         echo"</tr>";
         
     }
 }
 
 echo "<table>";
 echo"</center>";
 
?>
</body>
</html>