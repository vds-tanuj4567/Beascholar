<?php
session_start();
?>
<?php
$x=$_GET["brid"];
$y=$_GET["cid"];
$z=$_GET["cname"];
$conn=new mysqli("localhost:3306","root","tanuj","test");
if($conn->connect_error)
{
    die("connect:failed");
}
 else {

     $sql="insert into course values(".$x.",".$y.",'".$z."')";
     if($conn->query($sql))
     {
         echo"<center>values inserted successfully</center>";
         include('addcourse.html');
     }
     
}
?>

