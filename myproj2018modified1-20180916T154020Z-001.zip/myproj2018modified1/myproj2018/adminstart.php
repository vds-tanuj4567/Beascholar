<?php
session_start();
?>

<html>
<head>

<script>

function f13()
{
document.getElementById("k6").style.color="yellow";
}
function f14()
{
document.getElementById("k6").style.color="black";
}


</script>

<title>Home</title>
<style>
div {
height:10%;
width:100%;
background-color:powderblue;
text-align:center;
}
td
{
color:yellow;

text-align:center;

}
th
{
color:yellow;
background-color:red;
text-align:center;

}
body
{
background-image: url("389093.jpg");
color:yellow;
font-size:30px;

}
button.button:hover {background-color: #3e8e41}
#p1{
    width:280px;
    height:50px;
    font-size:20px;
    
    
}
#p2{
    text-decoration:none;
    color:red;
}
</style>
</head>
<body >
<div id="k6" onmouseover="f13()" onmouseout="f14()"><font size="100">E learning</font></div>

<?php
echo "WELCOME  ";
$n=$_SESSION["adminname"];
echo $n;
?>
<br>
<br>

<center>
<button type="button" class="button" id="p1"><a id="p2" href="addbranch.html">add branch</a></button>
<button type="button" class="button" id="p1"><a id="p2" href="addcourse.html">add course</a></button>
<button type="button" class="button" id="p1"><a id="p2" href="addaquestion.html">add a question</a></button>

</center>


</body>
</html>









