<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1>Operators in C</h1>
        <p>
            An operator is simply a symbol that is used to perform operations. There can be many types of operations like arithmetic, logical, bitwise etc.
<br>
There are following types of operators to perform different types of operations in C language.
<br>
1.Arithmetic Operators<br>
    2.Relational Operators<br>
   3. Shift Operators<br>
    4.Logical Operators<br>
    5.Bitwise Operators<br>
    6.Ternary or Conditional Operators<br>
    7.Assignment Operator<br>
    8.Misc Operator<br>
        </p>
        <h1>Precedence and Associativity</h1>
        <p>
            The precedence of operator species that which operator will be evaluated first and next.<br> The associativity specifies the operators direction to be evaluated, it may be left to right or right to left.<br>
            <img src="precedence.png">
            <br>
        <h1>Type Casting:</h1>
            Type casting allows us to convert one data type into other.<br> In C language, we use cast operator for type casting which is denoted by (type).

Syntax:
<br>

(type)value;<br>
<h3>Implicit TypeCasting:</h3><br>
int f= 9/4;  <br>
printf("f : %d\n", f );//Output: 2  <br>
<h3>Explicit TypeCasting:</h3><br>
float f=(float) 9/4;  <br>
printf("f : %f\n", f );//Output: 2.250000  <br>
        </p>


        </p>
        <a href="cp2b.php"><img src='next1.jpeg' width=10% height=10%></a>
    </body>
</html>

