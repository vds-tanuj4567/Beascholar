<?php
session_start();
?>
<?php
$conn=new mysqli("localhost:3306","root","tanuj","test");
if($conn->connect_error)
{
    die("connect:failed");
}
 else {
     $d=$_SESSION["username"];
    $sql="select * from  exam where username='".$d."' ";
    $r1=$conn->query($sql);
    $e="ch1";
    if($r1->num_rows)
    {
        while($row=$r1->fetch_assoc())
        {
            if($row["chapters"]==$e)
            {
                if($row["score"]>=5)
                {
                    header("Location:cp2a.php");
                    
                    
                }
                else
                {
                    echo "Sorry,you didn't get enough score in quiz to move forward to next chapter";
                    include('cp1b.php');
                }
            }
            
                else
                {
                    echo "Sorry,you didn't get enough score in quiz to move forward to next chapter";
                    include('cp1b.php');
                }
            
        }
    }
    else
                {
                    echo "Sorry,you didn't complete all the given work to move forward to next chapter";
                    include('cp1b.php');
                }
 
     
 }
