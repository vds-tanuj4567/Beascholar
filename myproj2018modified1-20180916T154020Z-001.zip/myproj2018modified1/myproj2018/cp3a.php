<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1>ARRAYS:</h1>
        <p>
            Array in C language is a collection or group of elements (data).<br> All the elements of c array are homogeneous (similar). It has contiguous memory location.<br>
            <br>
C array is beneficial if you have to store similar elements.<br> Suppose you have to store marks of 50 students, one way to do this is allotting 50 variables.<br> So it will be typical and hard to manage. For example we can not access the value of these variables with only 1 or 2 lines of code.<br>

Another way to do this is array. By using array, we can access the elements easily. Only few lines of code is required to access the elements of array.<br>
<b>Advantage of C Array</b><br>

1) Code Optimization: Less code to the access the data.<br>

2) Easy to traverse data: By using the for loop, we can retrieve the elements of an array easily.<br>

3) Easy to sort data: To sort the elements of array, we need a few lines of code only.<br>

4) Random Access: We can access any element randomly using the array.<br>
<b>Disadvantage of C Array</b><br>

1) Fixed Size: Whatever size, we define at the time of declaration of array, we can't exceed the limit. So, it doesn't grow the size dynamically like LinkedList which we will learn later.<br>
<b>Declaration of array</b><br>

We can declare an array in the c language in the following way.<br>

    data_type array_name[array_size];  
<br>
Now, let us see the example to declare array.<br>

    int marks[5];  <br>
    <b>Initialisation of Array</b><br>
    marks[0]=10;<br>
    marks[1]=20;<br>
    marks[2]=30;<br>
    marks[3]=40;<br>
    marks[4]=50;<br>
        <h3>TWO DIMENSIONAL ARRAY:</h3>
        The two dimensional array in C language is represented in the form of rows and columns, also known as matrix. <br>It is also known as array of arrays or list of arrays.
<br>
The two dimensional, three dimensional or other dimensional arrays are also known as multidimensional arrays.<br>

<b>Declaration of two dimensional Array in C</b><br>

We can declare an array in the c language in the following way.<br>

    data_type array_name[size1][size2];  <br>

A simple example to declare two dimensional array is given below.<br>

    int twodimen[4][3];  <br>

Here, 4 is the row number and 3 is the column number.<br>
<b>Initialization of 2D Array in C</b> <br>

A way to initialize the two dimensional array at the time of declaration is given below.<br>

    int arr[4][3]={{1,2,3},{2,3,4},{3,4,5},{4,5,6}};  <br>
    <h1>STRINGS:</H1>
    String in C language is an array of characters that is terminated by \0 (null character).<BR>

There are two ways to declare string in c language.<BR>

    1.By char array<BR>
    2.By string literal<BR>

1.Let's see the example of declaring string by char array in C language. <BR>

    char ch[4]={'c','b','i','t', '\0'};  <BR>
    2.
        char ch[]="javatpoint";  <BR>
        <h3>String Manipulation Functions in c</h3>
        <img src="stringfun.jpg">


        </p>
        <a href="cp3b.php"><img src='next1.jpeg' width=10% height=10%></a>
    </body>
</html>
