<html>
    <head>
        <script>
            history.pushState(null,null,document.title);
            window.addEventListener('popstate',function ()
            {
                history.pushState(null,null,document.title);
            })
            </script>
            <style>
                body
{
background-image: url("389093.jpg");
color:yellow;
font-size:30px;

}
            </style>
    </head>
    <body><?php
session_start();
session_unset();
session_destroy();
$_SESSION=array();
echo "<center><h3>logged out successfully</h3></center>";
include('existuser.html');

?>
    </body>
</html>

