<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1>First C Program:</h1>
<P Before starting the abcd of C language, you need to learn how to write, compile and run the first c program.

To write the first c program, open the C console and write the following code:
<BR>
    #include "stdio.h"   <BR> 
        int main(){    <br>
        printf("Hello C Language"); //printing the output on console    <br>
        return 0;   <br>
        }  <br>
#include <stdio.h> includes the standard input output library functions. The printf() function is defined in stdio.h .
    <br>
int main() The main() function is the entry point of every program in c language.<br>

printf() The printf() function is used to print data on the console.<br>
; used for terminating a statement.<br>
// used for describing something(single line comments)<br>
{........} program starts with and ends with these brackets.<br>

return 0 The return 0 statement, returns execution status to the OS. The 0 value is used for successful execution and 1 for unsuccessful execution.
<br>
</p>
<h1>Execution flow of C Program</h1>
<p>Let's try to understand the flow of above program by the figure given below.

1) C program (source code) is sent to preprocessor first. The preprocessor is responsible to convert preprocessor directives into their respective values. The preprocessor generates an expanded source code.
<br>
2) Expanded source code is sent to compiler which compiles the code and converts it into assembly code.
<br>
3) The assembly code is sent to assembler which assembles the code and converts it into object code. Now a simple.obj file is generated.
<br>
4) The object code is sent to linker which links it to the library such as header files. Then it is converted into executable code. A simple.exe file is generated.
<br>
5) The executable code is sent to loader which loads it into memory and then it is executed. After execution, output is sent to console.
<br>
</p>
<h1>printf and scanf in c</h1>
<p>
    
The printf() and scanf() functions are used for input and output in C language. Both functions are inbuilt library functions, defined in stdio.h (header file).
<br>
printf() function
<br>
The printf() function is used for output. It prints the given statement to the console.
<br>
The syntax of printf() function is given below:
<br>
<b>printf("format string",argument_list); </b> 
<br>
The format string can be %d (integer), %c (character), %s (string), %f (float) etc.
<br>
scanf() function
<br>
The scanf() function is used for input. It reads the input data from the console.
<br>
<b>scanf("format string",argument_list);</b>  

</p>
<h1>
    Variables in C
</h1>
<p>
    

A variable is a name of memory location. It is used to store data. Its value can be changed and it can be reused many times.
<br>
It is a way to represent memory location through symbol so that it can be easily identified.
<br>
Let's see the syntax to declare a variable:
<br>
type variable_list;  
The example of declaring variable is given below:
<br>
int a;  
float b;  
char c;  
<br>
<b>Rules</b>
<br>
A variable can have alphabets, digits and underscore.<br>
A variable name can start with alphabet and underscore only. It can't start with digit.<br>
No white space is allowed within variable name.<br>
A variable name must not be any reserved word or keyword e.g. int, float etc.<br>

</p>
<p>
    <b>Types of Variables:</b><br>
    <b>Local Variable</b><br>
A variable that is declared inside the function or block is called local variable.<br>

It must be declared at the start of the block.<br>

void function1(){  <br>
int x=10;//local variable <br>  
}  <br>
You must have to initialize the local variable before it is used.
<br>
<b>Global Variable</b><br>
A variable that is declared outside the function or block is called global variable. Any function can change the value of the global variable. It is available to all the functions.
<br>
It must be declared at the start of the block.
<br>
int value=20;//global variable <br> 
void function1(){  <br>
int x=10;//local variable  <br>
}  <br>
<b>Static Variable</b>
<br>
    A variable that is declared with static keyword is called static variable.
<br>
It retains its value between multiple function calls.
<br>
void function1(){<br>  
int x=10;//local variable <br>  
static int y=10;//static variable <br> 
x=x+1;  <br>
y=y+1;  <br>
printf("%d,%d",x,y);  <br>
}  <br>
    
</p>
<a href="cp1b.php"><img src='next1.jpeg' width=10% height=10%></a>
    </body>
</html>
