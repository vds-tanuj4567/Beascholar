<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1>Control Statements:</h1>
        <p>
        <H3>if:</h3>
       The single if statement in C language is used to execute the code if condition is true. <br>The syntax of if statement is given below:
       <br>
       if(expression){  <br>
    //code to be executed  
    }  <br>
    <h3>if - else:</h3>
    The if-else statement in C language is used to execute the code if condition is true or false. The syntax of if-else statement is given below:
    <br>
    if(expression){  <br>
    //code to be executed if condition is true  <br>
    }else{  <br>
    //code to be executed if condition is false  <br>
    }  
    <h3>else if ladder:</h3>
    The if else-if statement is used to execute one code from multiple conditions. The syntax of if else-if statement is given below:
    <br>
    if(condition1){  <br>
    //code to be executed if condition1 is true  <br>
    }else if(condition2){  <br>
    //code to be executed if condition2 is true  <br>
    }  <br>
    else if(condition3){  <br>
    //code to be executed if condition3 is true  <br>
    }  <br>
    ...  
    else{  <br>
    //code to be executed if all the conditions are false  <br>
    }  <br>
    <h3>Switch Statement:</h3>
    The switch statement in C language is used to execute the code from multiple conditions. It is like if else-if ladder statement.
<br>
The syntax of switch statement in C language is given below:<br>

    switch(expression){    <br>
    case value1:    <br>
     //code to be executed;    <br>
     break;  //optional  <br>
    case value2:    <br>
     //code to be executed;    <br>
     break;  //optional  <br>
    ......    <br>
        
    default:  <br>    
     code to be executed if all cases are not matched;    <br>
     }    <br>


        </p>
        <h1>Loop:</h1>
        
        <p>
            The loops in C language are used to execute a block of code or a part of the program several times.
            <br>
In other words, it iterates a code or group of code many times.
<b>Advantage of loops in C</b>

1) It saves code.<br>

2) It helps to traverse the elements of array (which is covered in next pages).<br>
        <h3>Types of Loops:</h3>
        There are three types of loops in C language that is given below:

    1.do while<br>
    2.while<br>
    3.for<br>

do-while loop in C<br>

It iterates the code until condition is false. Here, condition is given after the code. So at least once, code is executed whether condition is true or false.<br>

It is better if you have to execute the code at least once.<br>

The syntax of do-while loop in c language is given below: <br>

    do{  <br>
    //code to be executed  <br>
    }while(condition);  <br>
<b>while loop in C</b> <br>

Like do while, it iterates the code until condition is false. Here, condition is given before the code. So code may be executed 0 or more times.
<br>
It is better if number of iteration is not known by the user.<br>

The syntax of while loop in c language is given below:<br>

    while(condition){  <br>
    //code to be executed  <br>
    }  <br>


<b>for loop in C</b> <br>

Like while, it iterates the code until condition is false.<br> 
Here, initialization, condition and increment/decrement is given before the code. So code may be executed 0 or more times.<br>

It is good if number of iteration is known by the user.<br>

The syntax of for loop in c language is given below:<br>

for(initialization;condition;incr/decr){ <br> 
    //code to be executed  <br>
    }  <br>
    <p><h3>Break Statement:</h3>
        The break statement in C language is used to break the execution of loop (while, do while and for) and switch case.
        <br>
In case of inner loops, it terminates the control of inner loop only.
<br>
There can be two usage of C break keyword:<br>

1.With switch case<br>
2.With loop<br>

Syntax:
<br>
jump-statement;  <br>
break;  <br>
<h3>Continue Statement:</h3>
The continue statement in C language is used to continue the execution of loop (while, do while and for). It is used with if condition within the loop.
<br>
In case of inner loops, it continues the control of inner loop only.<br>
Syntax:
<br>
jump-statement;  <br>
continue;  <br>
<h3>GOTO statement:</h3>
The goto statement is known as jump statement in C language.<br> It is used to unconditionally jump to other label. It transfers control to other parts of the program.
<br>
It is rarely used today because it makes program less readable and complex.<br>

Syntax:<br>

goto label;  <br>
    </p>
    <form method="GET" action="cp2.php">
<input type="submit" value="Next">
</form>
    </body>
</html>

