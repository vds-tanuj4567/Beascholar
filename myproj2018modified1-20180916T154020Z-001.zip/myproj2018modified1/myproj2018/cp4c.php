<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
                
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    
    </head>
    <body>
        <h1>Unions in C</h1>
        <p>
            Like structure, Union in c language is a user defined datatype that is used to hold different type of elements.

But it doesn't occupy sum of all members size. It occupies the memory of largest member only. It shares memory of largest member.
difference between structure and union<br>
<img src="su.jpeg" width="30%"><br>
        <h2>Advantage of union over structure</h2><br>

It occupies less memory because it occupies the memory of largest member only.<br>
<h2>Disadvantage of union over structure</h2>
<br>
It can store data in one member only.<br>
<h2>Defining union</h2>
<br>
The union keyword is used to define union. Let's see the syntax to define union in c.<br>

    union union_name <br>   
    {  <br>
        data_type member1;  <br>
        data_type member2; <br>  
        .  <br>
        .  <br>
        data_type memberN;  <br>
    };  <br>

Let's see the example to define union for employee in c.<br>

    union employee  <br>
    {   int id;  <br>
        char name[50];  <br>
        float salary;  <br>
        };  <br>
        </p>
        <form method="GET" action="cp2.php">
<input type="submit" value="Next">
</form>
    </body>
</html>
