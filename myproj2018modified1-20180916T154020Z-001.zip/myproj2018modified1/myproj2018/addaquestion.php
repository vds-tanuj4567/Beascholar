<?php
session_start();
?>
<?php
$x=$_GET["qid"];
$y=$_GET["cid"];
$z=$_GET["question"];
$a=$_GET["op1"];
$b=$_GET["op2"];
$c=$_GET["op3"];
$d=$_GET["op4"];
$e=$_GET["answer"];
$conn=new mysqli("localhost:3306","root","tanuj","test");
if($conn->connect_error)
{
    die("connect:failed");
}
 else {

     $sql="insert into quiz values(".$x.",".$y.",'".$z."','".$a."','".$b."','".$c."','".$d."','".$e."')";
     if($conn->query($sql))
     {
         echo"<center>values inserted successfully</center>";
         include('addaquestion.html');
     }
     
}
?>


