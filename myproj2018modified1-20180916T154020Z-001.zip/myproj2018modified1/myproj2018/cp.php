<?php
session_start();
$_SESSION["course"]=1001;
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        <style>
body
{
background-image: url("389093.jpg");
color:yellow;
font-size:30px;

}
#p1
{
    width:100px;
    height:60px;
}
</style>
    </head>
    <body>
        <h1>C Programming:</h1>
        <h3>Topics covered in this course</h3>
        <ul>
            <li>history of c,tokens of c</li>
            <li>operators,control statements</li>
            <li>functions,arrays,strings</li>
            <li>pointers,structures,unions</li>
            <li>files in c,command line arguments,pre processor directives</li>
        </ul>
        <p>This course contains    videos,   assignments with online quiz,detailed notes regarding each topic</p>
        <form method="GET" action="cpmain.php">
            <input type="submit" id="p1" value="Enroll Now">
        </form>
    </body>
</html>

