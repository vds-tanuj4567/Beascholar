<?php
session_start();
?>
<html>
    <body>
        <?php
        
        $x=$_GET["name"];
        $y=$_GET["email"];
        $z=$_GET["study"];
        $a=$_GET["user"];
        $b=$_GET["password"];
        $c=$_GET["password1"];
        $_SESSION["username"]=$a;
        $d=0;
        
        $conn=new mysqli("localhost:3306","root","tanuj","test");
        if($conn->connect_error)
        {
            die("connect:failed");
        }
     else
     {global $d;
         
           
         if($b==$c)
         {
             $sql1="select username from s1";
             $r1=$conn->query($sql1);
             if($r1->num_rows)
             {
                 while($row=$r1->fetch_assoc())
                 {
                     if($row["username"]==$a)
                     {
                        global $d;
                        $d=1;
                        break;
                         
                     }
                 }
             }
             if($d==0)
             {
        
          $sql="insert into s1 values('".$x."','".$y."','".$z."','".$a."','".$b."')";
        
       $conn->query($sql);
      
	
	
 	
require'PHPMailer-5.2.25/PHPMailerAutoload.php'; 
$x1=rand(10000,50000);
$mail=new PHPMailer();
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'tls';
	$mail->Host ='smtp.gmail.com';
	$mail->Port = '587';
	$mail->isHTML(true);
	$mail->Username = 'elearninghyd043@gmail.com';
	$mail->Password = 'pokemonduel';
	$mail->SetFrom('elearninghyd043@gmail.com');
	$mail->Subject = 'e learning';
	$mail->Body = "your otp is "."$x1";
        $mail->AddAddress($y);
        $_SESSION["otp"]=$x1;
	
 	if(!$mail->Send()) {
   	 echo "Mailer Error: " . $mail->ErrorInfo;
	}
	else
	{
            header("location:otp.html");
	}

       //header("Location:start1.php");
             }
             else
             {
                 echo "username is incorrect";
     include("login.html");
             }
         }
 else {
     echo "password is incorrect";
     include("login.html");
 }
           
                }
          ?>
    </body>
</html>
        
        
       
    


