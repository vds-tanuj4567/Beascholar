<?php

$x=$_POST["brid"];
$y=$_POST["cid"];
$z=$_POST["cname"];
if(isset($_POST["submit"]))
{
$check= getimagesize($_FILES["image"]["tmp_name"]);

if($check==TRUE)
{
    $image = $_FILES['image']['tmp_name'];
        $imgContent = addslashes(file_get_contents($image));
        $conn=new mysqli("localhost:3306","root","tanuj","test");
        if($conn->connect_error)
        {
            die("connect:failed");
        }
        else
        {
            $sql="insert into course1 values(".$x.",".$y.",'".$z."','".$imgContent."')";
            if($conn->query($sql))
            {
                echo "inserted";
                include('addcourse.html');
            }
                else
                {
                    echo"not inserted";
                }
        }
}
else
{
    echo"not image";
}

}
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

