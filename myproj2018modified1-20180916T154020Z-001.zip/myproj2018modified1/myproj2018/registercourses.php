<?php
session_start();
?>
<html>
    <head>
        <style>
            body
            {
                background-image: url("e5.jpg");
                color:yellow;
                font-size:30px;

            }
        </style>
    </head>
</html>
<?php
$x=$_SESSION["username"];
$conn= new mysqli("localhost:3306","root","tanuj","test");
  if($conn->connect_error)
  {
      die("connect:failed");
  }
 else {
 $sql="select cname from course where cid=(select cid from enroll where username='".$x."')";     
 $r1=$conn->query($sql);
 if($r1->num_rows)
 {echo "<center>";
     while($row=$r1->fetch_assoc())
     {//echo"hiii";
         if($row[cname]=="C Programming")
         {
         echo "<a href='cp1.php' style='color:yellow;' class='p1'>$row[cname]</a>";
         }
     }
 }
}
  ?>

