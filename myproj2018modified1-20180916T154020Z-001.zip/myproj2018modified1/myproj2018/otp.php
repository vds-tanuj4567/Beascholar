<?php
session_start();
?>
<?php
$x=$_SESSION["otp"];
$y=$_GET["name"];
if($x==$y)
{
    header("Location:start1.php");
}
 else {
echo "invalid otp";
include('otp.html');
}
?>
