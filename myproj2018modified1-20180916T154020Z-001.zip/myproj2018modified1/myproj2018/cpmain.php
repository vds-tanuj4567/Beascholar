<?php
session_start();
?>
<?php
$x=$_SESSION["username"];
$y=$_SESSION["course"];
$conn= new mysqli("localhost:3306","root","tanuj","test");
  if($conn->connect_error)
  {
      die("connect:failed");
  }
  else
  {
      $sql="insert into enroll values('".$x."',".$y.") ";
      if($conn->query($sql))
      {
          
          header("Location:cp1.php");
      }
      
  }
  
?>

