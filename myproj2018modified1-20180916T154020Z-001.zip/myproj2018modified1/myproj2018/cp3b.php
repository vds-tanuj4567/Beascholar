<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1>FUNCTIONS:</H1>
        The function in C language is also known as procedure or subroutine in other programming languages.<br>

To perform any task, we can create function. A function can be called many times. It provides modularity and code reusability.<br>
<b>Advantage of functions in C:</b><br>

There are many advantages of functions.<br>
1) Code Reusability<br>

By creating functions in C, you can call it many times. So we don't need to write the same code again and again.<br>
2) Code optimization<br>

It makes the code optimized, we don't need to write much code.<br>
<b>Types of Functions</b><br>

There are two types of functions in C programming:
<br>
Library Functions: are the functions which are declared in the C header files such as scanf(), printf(), gets(), puts(), ceil(), floor() etc.<br>
User-defined functions: are the functions which are created by the C programmer, so that he/she can use it many times.<br> It reduces complexity of a big program and optimizes the code.<br>
<h3>Declaration:</h3>
The syntax of creating function in c language is given below:<br>

return_type function_name(data_type parameter...){  <br>
//code to be executed  <br>
    }  <br>
    <b>example:</b><br>
    1.void hello(){  <br>
    printf("hello c");  <br>
    }  <br>
    2.    int get(){  <br>
    return 777;  <br>
    }  <br>
    <h3>Parameters in C:</h3>
    <br>
        int cube(int n){  <br>
    return n*n*n;  <br>
    }  <br>
    <h3>Calling a function in c</h3>
    variable=function_name(arguments...);  <br>
    ex:hello();<br>
    cube(5);<br>
    <h2>Call by value in C</h2>

In call by value, original value is not modified.<br>

In call by value, value being passed to the function is locally stored by the function parameter in stack memory location. <br>If you change the value of function parameter, it is changed for the current function only. It will not change the value of variable inside the caller method such as main().<br>

Let's try to understand the concept of call by value in c language by the example given below:<br>
Code:
    #include "stdio.h " <br>
    void change(int num) { <br>   
        printf("Before adding value inside function num=%d \n",num); <br>   
        num=num+100;    <br>
        printf("After adding value inside function num=%d \n", num);  <br>  
    }    
    int main() {    <br>
        int x=100;    <br>
        printf("Before function call x=%d \n", x);<br>    
        change(x);//passing value in function    <br>
        printf("After function call x=%d \n", x);    <br>
    return 0;  <br>
    }    <br>

Output<br>

Before function call x=100<br>
Before adding value inside function num=100<br>
After adding value inside function num=200<br>
After function call x=100<br>

<h2>Call by reference in C</h2>

In call by reference, original value is modified because we pass reference (address).<br>

Here, address of the value is passed in the function, so actual and formal arguments shares the same address space.<br> Hence, value changed inside the function, is reflected inside as well as outside the function.<br>

Note: To understand the call by reference, you must have the basic knowledge of pointers.<br>

Let's try to understand the concept of call by reference in c language by the example given below:<br>
Code:<br>
    #include"stdio.h"  <br>
    void change(int *num) {    <br>
        printf("Before adding value inside function num=%d \n",*num);    <br>
        (*num) += 100;    
        printf("After adding value inside function num=%d \n", *num);    <br>
    }      
    int main() {    <br>
        int x=100;    <br>
        printf("Before function call x=%d \n", x);    <br>
        change(&x);//passing reference in function    <br>
        printf("After function call x=%d \n", x);    <br>
    return 0;  <br>
    }    <br>

    Output<br>

Before function call x=100<br>
Before adding value inside function num=100<br>
After adding value inside function num=200<br>
After function call x=200<br>



<h2>Recursion in C</h2>

When function is called within the same function, it is known as recursion in C. <br>The function which calls the same function, is known as recursive function.
<br>
A function that calls itself, and doesn't perform any task after function call, is know as tail recursion. In tail recursion, we generally call the same function with return statement. An example of tail recursion is given below.
<br>
Let's see a simple example of recursion.
<br>
recursionfunction(){  <br>
recursionfunction();//calling self function  <br>
}  <br>

<form method="GET" action="cp2.php">
<input type="submit" value="Next">
</form>
    </body>
</html>
