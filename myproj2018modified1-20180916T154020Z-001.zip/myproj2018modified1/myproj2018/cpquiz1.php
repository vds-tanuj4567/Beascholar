
<?php
session_start();
?>
<?php

$conn=new mysqli("localhost:3306","root","tanuj","test");
if($conn->connect_error)
{
    die("connect:failed");
}
else
{
    $sql="select * from quiz limit 10";
    $r1=$conn->query($sql);
    $c=1;
    if($r1->num_rows)
    {
        echo "<form method='GET' action='cpquiz1out.php'>"; 
        while($row=$r1->fetch_assoc())
        {
            echo "<p>$c.$row[questions]</p>";
            echo "<div><input type='radio' name=string($c) value='$row[op1]'>$row[op1]<br>";
            echo "<input type='radio' name=string($c) value='$row[op2]'>$row[op2]<br>";
            echo "<input type='radio' name=string($c) value='$row[op3]'>$row[op3]<br>";
            echo "<input type='radio' name=string($c) value='$row[op4]'>$row[op4]<br></div>";
            $c++;
            
        }
        echo "<input type='submit'>";
        echo "</form>";
    }
    
}
?>

