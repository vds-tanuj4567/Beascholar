<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1>Pointers in C</h1>
        <p>
            The pointer in C language is a variable, it is also known as locator or indicator that points to an address of a value.
            c pointers<br>
            Advantage of pointer<br>

            1) Pointer reduces the code and improves the performance, <br>it is used to retrieving strings, trees etc. and used with arrays, structures and functions.<br>

            2) We can return multiple values from function using pointer.<br>

            3) It makes you able to access any memory location in the computer's memory.<br>
            Usage of pointer:<br>

            There are many usage of pointers in c language.<br>
            1) Dynamic memory allocation<br>

            In c language, we can dynamically allocate memory using malloc() and calloc() functions where pointer is used.<br>
2) Arrays, Functions and Structures
<br>
Pointers in c language are widely used in arrays, functions and structures. It reduces the code and improves the performance.
<br>
& (ampersand sign):<br>	1.address of operator<br>	2.determines the address of a variable.<br>
* (asterisk sign):<br>	1.indirection operator<br>	2.accesses the value at the address.<br>
Declaring a pointer
<br>
The pointer in c language can be declared using * (asterisk symbol).<br>

int *a;//pointer to int  <br>
    char *c;//pointer to char  <br>
        <h3>NULL Pointer</h3>

A pointer that is not assigned any value but NULL is known as NULL pointer. If you don't have any address to be specified in the pointer at the time of declaration, you can assign NULL value. It will a better approach.
<br>
int *p=NULL;<br>
<h3>Pointer to Pointer in C(double pointer):</h3><br>
In C pointer to pointer concept, a pointer refers to the address of another pointer.
<br>
In c language, a pointer can point to the address of another pointer which points to the address of a value. Let's understand it by the diagram given below:
pointer to pointer in c<br>

Let's see the syntax of pointer to pointer.<br>

int **p2;  <br>

    C pointer to pointer example<br>

Let's see an example where one pointer points to the address of another pointer.<br>
C pointer to pointer example<br>



<img src="pointertopointer.jpeg" width="30%">
<h2>Pointer Arithmetic in C</h2><br>

In C pointer holds address of a value, so there can be arithmetic operations on the pointer variable. Following arithmetic operations are possible on pointer in C language:
<br>
    Increment<br>
    Decrement<br>
    Addition<br>
    Subtraction<br>
    Comparison<br>

Incrementing Pointer in C<br>

Incrementing a pointer is used in array because it is contiguous memory location. Moreover, we know the value of next location.
<br>
Increment operation depends on the data type of the pointer variable. The formula of incrementing pointer is given below:
<br>
    new_address= current_address + i * size_of(data type)  
<br>
32 bit
<br>
For 32 bit int variable, it will increment to 2 byte.<br>
64 bit<br>

For 64 bit int variable, it will increment to 4 byte.<br>

Let's see the example of incrementing pointer variable on 64 bit OS.
<br>
    #include<stdio.h>  <br>
    int main(){  <br>
    int number=50;        <br>
    int *p;//pointer to int      <br>
    p=&number;//stores the address of number variable    <br>    
    printf("Address of p variable is %u \n",p);        <br>
    p=p+1;       <br>
    printf("After increment: Address of p variable is %u \n",p); <br>      
    return 0;  <br>
    }    <br>

Output<br>

Address of p variable is 3214864300 <br>
After increment: Address of p variable is 3214864304 <br>

<h3>Decrementing Pointer in C</h3><br>

Like increment, we can decrement a pointer variable. The formula of decrementing pointer is given below:
<br>
    new_address= current_address - i * size_of(data type)  
<br>
32 bit
<br>
For 32 bit int variable, it will decrement to 2 byte. <br>
64 bit<br>

For 64 bit int variable, it will decrement to 4 byte.
<br>
Let's see the example of decrementing pointer variable on 64 bit OS.
<br>
    #include <stdio.h>            <br>
    void main(){            <br>
    int number=50;        <br>
    int *p;//pointer to int      <br>
    p=&number;//stores the address of number variable <br>        
    printf("Address of p variable is %u \n",p);        <br>
    p=p-1;       <br>
    printf("After decrement: Address of p variable is %u \n",p);     <br>   
    }      <br>

Output<br>

Address of p variable is 3214864300 <br>
After decrement: Address of p variable is 3214864296 <br>

<h3>C Pointer Addition</h3><br>

We can add a value to the pointer variable. The formula of adding value to pointer is given below:
<br>
    new_address= current_address + (number * size_of(data type))  
<br>
32 bit
<br>
For 32 bit int variable, it will add 2 * number.<br>
64 bit<br>

For 64 bit int variable, it will add 4 * number.<br>

Let's see the example of adding value to pointer variable on 64 bit OS.
<br>
    #include<stdio.h>  <br>
    int main(){  <br>
    int number=50;        <br>
    int *p;//pointer to int      <br>
    p=&number;//stores the address of number variable <br>        
    printf("Address of p variable is %u \n",p);        <br>
    p=p+3;   //adding 3 to pointer variable    <br>
    printf("After adding 3: Address of p variable is %u \n",p); <br>       
    return 0;  <br>
    }    <br>

Output

Address of p variable is 3214864300 <br>
After adding 3: Address of p variable is 3214864312<br>

As you can see, address of p is 3214864300. But after adding 3 with p variable, it is 3214864312 <br>
i.e. 4*3=12 increment. Since we are using 64 bit OS, it increments 12. But if we were using 32 bit OS, <br>
it were incrementing to 6 only i.e. 2*3=6. As integer value occupies 2 byte memory in 32 bit OS.<br>
<h3>C Pointer Subtraction</h3>
<br>
Like pointer addition, we can subtract a value from the pointer variable. The formula of subtracting value from pointer variable is given below:
<br>
    new_address= current_address - (number * size_of(data type))  
<br>
32 bit
<br>
For 32 bit int variable, it will subtract 2 * number.<br>
64 bit<br>

For 64 bit int variable, it will subtract 4 * number.<br>

Let's see the example of subtracting value from pointer variable on 64 bit OS.<br>

#include "stdio.h"  <br>
    int main(){  <br>
    int number=50;   <br>     
    int *p;//pointer to int <br>      
    p=&number;//stores the address of number variable <br>       
    printf("Address of p variable is %u \n",p);        <br>
    p=p-3; //subtracting 3 from pointer variable    <br>
    printf("After subtracting 3: Address of p variable is %u \n",p); <br>       
    return 0;  <br>
    }<br>
        </p>
        <a href="cp4b.php"><img src='next1.jpeg' width=10% height=10%></a>
    </body>
</html>