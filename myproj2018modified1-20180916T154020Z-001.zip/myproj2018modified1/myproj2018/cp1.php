<?php
session_start();
$_SESSION["course"]=1001;
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1>HISTORY OF C PROGRAMMING
            LANGUAGE</h1>
        <h3>Evolution of C programming language:</h3>
        <p>

C has often been termed as a "Pseudo high level language" or a "Middle level
language" by many programmers. This is not because of its lack of
programming power but because of its capability to access the system's low
level functions. In fact C was invented specifically to implement UNIX. C
instructions are compiled to assembly code, therefore, depending on the
complexity of the code and on the compiler optimization capabilities, C code
may run as fast as assemby.
        </p>
        <p>
Ken Thompson created the B language in 1969 from Martin Richard's BCPL
(Basic Combined Programming Language). He used assembly language and
B to produce the initial versions of the UNIX operating system. BCPL and B
were typeless languages in which variables were simply words in
memory. Dennis Ritchie of Bell Laboratories later converted B into C by
retaining most of B's syntax in 1972 and wrote the first compiler. This was
implemented on DEC's PDP 11 and it was first used as the system's language
for rewriting the UNIX operating system. Later on, UNIX, its tools and C
grew simultaneously. In 1978, Kernighan and Ritchie wrote a book entitled
'The C Programming Language' that became the language definition for
almost a decade. Beginning in 1983, the ANSI X3J11 committee was asked
to standardize the C language. The result was ANSI C, a standard which was 
adopted in 1988. It is not forced upon any programmer, but since it is so
widely accepted, it would be economically unwise for any systems
programmer or compiler writer not to conform to the standard.</p>
        <h3>Features of C Language</h3>
        <ul>
<li>C is a procedure-based programming language. This means the program
is viewed as a means to solve a problem. Various functions modules or
code blocks are thus, written to solve this problem.</li>
<li>C functions can accept parameters and return values and perform
variety of tasks like input from the user, displaying the information, etc.
· C is simple and easy to learn and use. The main components like builtin
functions, operators, keywords are small in number.</li>
<li>In C, errors are checked only at compile time. The compiled code
though have no safety checks for bad type casts, bad array indices, or
bad pointers.</li>
<li>C works best for small projects where performance is important.</li>
<li>C contains the capability of assembly language with the features of high
level language which can be used for creating software packages,
system software etc</li>
<li>C is highly portable. C programs written on one computer can run on
    other computer without making any changes in the program.</li>
        </ul>
        
        <h3>Uses of C</h3>
<p>C's wide acceptance and efficiency is the reason why libraries of several
other applications are often implemented in C. Some of the applications
using C in its kernels are:</p>
<p>Uses of C are many in addition to Systems programming. Some of
    which are as follows :</p>
<ul>
<li>Language compilers and interpreters</li>
<li>Device drivers</li>
<li>Telecom applications</li>
<li>Network programming</li>
<li>Digital Signal processing applications</li>
<li>Database applications</li>
<li>Text editors</li>
</ul>

<h3>Videos:
    <a class="p1" href="https://youtu.be/fwfmjUgx0LM">https://youtu.be/fwfmjUgx0LM</a></h3>
<a class="p1" href='cpquiz1.php'>Quiz</a>   
<a href="cp1a.php"><img src='next1.jpeg' width=10% height=10%></a>
<!--<form method="GET" action="cp2.php">
<input type="submit" value="Next">
</form>-->
    </body>
</html>



