<?php
session_start();
?>
<html>
    <body>
  <?php
  $x=$_GET["user"];
  $y=$_GET["password"];
  setcookie($x,$y,time()+86400*1,"/");
  $_SESSION["username"]=$x;
  $conn= new mysqli("localhost:3306","root","tanuj","test");
  if($conn->connect_error)
  {
      die("connect:failed");
  }
  else
  {
      $sql="select password from s1 where username='".$x."' ";
      
      $res=$conn->query($sql);
      //echo $res;
      
      if($res->num_rows)
      {
            while($row=$res->fetch_assoc())
           if($y==$row["password"])
              {
                  header("Location:start1.php");
              }
 else {
    echo 'incorrect password';
        include('existuser.html');
     
 }
       }
      
 else {
     echo 'incorrect data';
        include('existuser.html');
      }
  }
  ?>
    </body>
  
</html>

