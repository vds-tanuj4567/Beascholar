<?php
session_start();
?>

<html>
<head>

<script>
function f1()
{
document.getElementById("k").style.color="blue";
}
function f2()
{
document.getElementById("k").style.color="yellow";
}
function f3()
{
document.getElementById("k1").style.color="blue";
}
function f4()
{
document.getElementById("k1").style.color="yellow";
}
function f5()
{
document.getElementById("k2").style.color="blue";
}
function f6()
{
document.getElementById("k2").style.color="yellow";
}
function f7()
{
document.getElementById("k3").style.color="blue";
}
function f8()
{
document.getElementById("k3").style.color="yellow";
}
function f9()
{
document.getElementById("k4").style.color="blue";
}
function f10()
{
document.getElementById("k4").style.color="yellow";
}
function f11()
{
document.getElementById("k5").style.color="blue";
}
function f12()
{
document.getElementById("k5").style.color="yellow";
}
function f13()
{
document.getElementById("k6").style.color="yellow";
}
function f14()
{
document.getElementById("k6").style.color="black";
}
function f15()
{
document.getElementById("k7").style.color="blue";
}
function f16()
{
document.getElementById("k7").style.color="yellow";
}

</script>

<title>Home</title>
<style>
div {
height:10%;
width:100%;
background-color:powderblue;
text-align:center;
}
td
{
color:yellow;

text-align:center;

}
th
{
color:yellow;
background-color:red;
text-align:center;

}
body
{
background-image: url("e5.jpg");
color:yellow;
font-size:30px;

}
.button:hover {background-color: #3e8e41}

</style>
</head>
<body >
<div id="k6" onmouseover="f13()" onmouseout="f14()"><font size="100">E learning</font></div>
<table width=100% height=10%>

<tr >
<th ><a  id="k" onmouseover="f1()" onmouseout="f2()" style="text-decoration:none; color:yellow;" href=" ">home</a></th>
<th><a  id="k1" onmouseover="f3()" onmouseout="f4()" style="text-decoration:none; color:yellow;" href=" ">about</a></th>
<th><a  id="k2" onmouseover="f5()" onmouseout="f6()"  style="text-decoration:none; color:yellow;" href="branches.php">enroll courses</a></th>
<th><a  id="k3" onmouseover="f7()" onmouseout="f8()" style="text-decoration:none; color:yellow;" href=" ">search</a></th>
<th><a  id="k4" onmouseover="f9()" onmouseout="f10()"   style="text-decoration:none; color:yellow;" href="registercourses.php">register courses</a></th>
<th><a  id="k5" onmouseover="f11()" onmouseout="f12()" style="text-decoration:none; color:yellow;" href=" contactus.html">contact us</a></th>

<th><a  id="k7" onmouseover="f15()" onmouseout="f16()" style="text-decoration:none; color:yellow;" href="logout.php">logout</a></th>
</tr>

</table>
<?php
echo "WELCOME  ";
$n=$_SESSION["username"];
echo $n;
?>
<br>
<br>

<center>
<form valign="top">
<input type="search" name="name" style="width:300px ;height:50px; font-size:20px;">
<button  class="button"  type="button" style="width:70px ;height:50px;" >Search</button>
</form>
</center>
<p style="font-size:30px;color:yellow;">This website mainly provides to get the notes related to a particular subject.The notes which provide good information about subject and the these are uploaded by professors of different universities.It also helps in improving the skills of a student by conducting some suprising slip tests which helps in estimating the performance of a student.It also provides video related to a particular subject which a student can use it to get more clarity regarding the topic.</p>

</body>
</html>


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

