
<?php
session_start();
?>
<html>
    <body>
  <?php
  $x=$_GET["admin"];
  $y=$_GET["password"];
    $_SESSION["adminname"]=$x;
  $conn= new mysqli("localhost:3306","root","tanuj","test");
  if($conn->connect_error)
  {
      die("connect:failed");
  }
  else
  {
      $sql="select password from admin where adminname='".$x."' ";
      
      $res=$conn->query($sql);
      //echo $res;
      
      if($res->num_rows)
      {
            while($row=$res->fetch_assoc())
            {
           if($y==$row["password"])
              {
                  header("Location:adminstart.php");
              }
            
      
 else {
    echo 'incorrect password';
        include('admin.html');
     
 }
            }
            }
       
      
 else {
     echo 'incorrect data';
        include('admin.html');
      }
  }
  ?>
    </body>
  
</html>



