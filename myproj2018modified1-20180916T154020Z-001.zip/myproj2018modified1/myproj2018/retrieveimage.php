<html>
    <head>
<style>
body
{
background-image: url("e5.jpg");
color:yellow;
font-size:30px;

}
</style>
    </head>
</html>
<?php
$conn=new mysqli("localhost:3306","root","tanuj","test");
        if($conn->connect_error)
        {
            die("connect:failed");
        }
        else
        {
            $sql="select * from course1";
            $r1=$conn->query($sql);
            echo"<center>";
 echo"<table border=2 width=100% height=100%>";
 $c=1;
 
            if($r1->num_rows)
            {
                while($row=$r1->fetch_assoc())
                {
                    $s=$row['image'];
                    
                   echo '<td ><img src="data:image/jpg;base64,'.base64_encode($s).'"width="600" height="400"></td>';
                echo "<td ><a style='color:yellow; font-size:30px;' href='cp.php' class='p1'>$row[cname]</a></td>";
            echo "</tr>";
                }
                
            }
           echo "</table>";
           echo "</center>";
           
        }
?>

