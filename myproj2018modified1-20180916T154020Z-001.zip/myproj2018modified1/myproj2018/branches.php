<?php
session_start();
?>
<html>
    <head>
        <style>
body
{
background-image: url("e5.jpg");
color:yellow;
font-size:30px;

}
#p1{
    width:280px;
    height:50px;
}
#p2{
    width:100px;
    height:30px;
}
#p3
{
    text-align:right;
}
</style>
    </head>
    <body>
       
    </body>
</html>
<?php
$conn=new mysqli("localhost:3306","root","tanuj","test");
if($conn->connect_error)
{
    die("connect:failed");
}
else
{
    $sql="select bname from branch";
    $r1=$conn->query($sql);
     echo "<a style='color:yellow;' href='logout.php'>logout</a>";
    if($r1->num_rows)
    {echo "<center><h3>Select your Branch:</h3></center>";
        echo "<form method='GET' action='retrieveimage.php'>";
        echo"<center>";
        echo "<select name='branch[]' id='p1'>";
        while($row=$r1->fetch_assoc())
        {
            echo "<option name='branch' value='$row[bname]'>$row[bname]</option>";
        }
        echo "</select>";
        echo "<br>";
        echo "<br>";
        echo "  <input type='submit' id='p2'>";
        echo "</form>";
    }
}
?>



