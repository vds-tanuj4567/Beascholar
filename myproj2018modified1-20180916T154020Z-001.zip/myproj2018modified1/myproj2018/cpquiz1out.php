<?php
session_start();

?>
<?php
$conn=new mysqli("localhost:3306","root","tanuj","test");
if($conn->connect_error)
{
    die("connect:failed");
}
else
{
    $sql="select answer from quiz limit 10";
    $r1=$conn->query($sql);
    $c=1;
    $d=0;
    $e=$_SESSION["username"];
    
    if($r1->num_rows)
    {
        while($row=$r1->fetch_assoc())
        {
      //echo $_GET["string($c)"];
            if($row[answer]==$_GET["string($c)"])
            {
                
                $d=$d+1;
            }
            $c++;
        }
    }
    if($d>=5)
    {
        echo "Congratulations ".$_SESSION["username"];
    echo "<br>score is".$d;
    echo "<br>You are promoted to next chapter with".($d*10)."%";
    $w=$_SESSION["username"];
    $h=$_SESSION["course"];
    echo $w;
    echo $h;
    $ui="ch1";
    $sql1="insert into exam values('".$w."',".$h.",'".$ui."',".$d.")";
    if($conn->query($sql1))
    {
        echo "values inserted successfully";
    }
    else
    {
        echo "values not inserted";
    }
    }
    
     
}
?>


