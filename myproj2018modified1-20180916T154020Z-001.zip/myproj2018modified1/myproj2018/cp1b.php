<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
        <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1>Tokens of C</h1>
        <p>
        <h3>DataTypes in C</h3>
        <br>
        
A data type specifies the type of data that a variable can store such as integer, floating, character etc.
<br>
C Data Types
<br>
There are 4 types of data types in C language.
<br>

1.Basic Data Type	-> int, char, float, double <br>
2.Derived Data Type	-> array, pointer, structure, union <br>
3.Enumeration Data Type	->enum <br>
4.Void Data Type	->void <br>
<h3>KeyWords in c</h3>
<pre>
A keyword is a reserved word. You cannot use it as a variable name, constant name etc. <br>There are only 32 reserved words (keywords) in C language.

A list of 32 keywords in c language is given below:

auto	break	case	char	const	continue	default	do
double	else	enum	extern	float	for	goto	if
int	long	register	return	short	signed	sizeof          static
struct	switch	typedef	union	unsigned	void	volatile	while
<h3>Comments in C</h3>
1.Single line Comments
Syntax://statement
Ex://hiiiiii
2.Multi line comments
Syntax:/* 
    ........................
            */
ex:
        /* hiiiiiiii
            welcome to e-learning
        */</pre>

                </p>
   <form method="GET" action="cp2.php">
<input type="submit" value="Next">
</form> </body>
</html>
