<?php
session_start();
echo "<a style='color:yellow;' href='logout.php'>logout</a>";
?>
<html>
    <head>
         <style>
body
{
background-image: url("e5.jpg");
color:white;
font-size:20px;


}
a.p1{
    font-size:30px;
    text-decoration:none;
    color:cyan;
}
</style>
    </head>
    <body>
        <h1>Structures in C:</h1><br>
        Structure in c language is a user defined datatype that allows you to hold different type of elements.<br>

        Each element of a structure is called a member.<br>

        It works like a template in C++ and class in Java. You can have different type of elements in it.<br>

        It is widely used to store student information, employee information, product information, book information etc.<br>
        Defining structure<br>

        The struct keyword is used to define structure. Let's see the syntax to define structure in c.<br>

        struct structure_name   <br>
        {  <br>
        data_type member1;  <br>
        data_type member2;  <br>
        .  <br>
        .  <br>
        data_type memeberN;  <br>
    };  <br>

Let's see the example to define structure for employee in c.<br>

    struct employee  <br>
    {   int id;  <br>
        char name[50];  <br>
        float salary;  <br>
    };  <br>

Here, struct is the keyword, employee is the tag name of structure; id, name and salary are the members or fields of the structure. Let's understand it by the diagram given below:
<br>
        <img src="structure-in-c.png">
       <br>
       Declaring structure variable
       <br>

We can declare variable for the structure, so that we can access the member of structure easily. There are two ways to declare structure variable:
<br>
    By struct keyword within main() function <br>
    By declaring variable at the time of defining structure. <br>

1st way:<br>

Let's see the example to declare structure variable by struct keyword. It should be declared within the main function.
<br>
    struct employee <br>  
    {   int id;  <br>
        char name[50];  <br>
        float salary;  <br>
    };  <br>

Now write given code inside the main() function. <br>

    struct employee e1, e2;  <br>

2nd way:<br>

Let's see another way to declare variable at the time of defining structure.
<br>
    struct employee  <br>
    {   int id;  <br>
        char name[50];  <br>
        float salary;  <br>
    }e1,e2;  <br>

Which approach is good <br>

But if no. of variable are not fixed, use 1st approach. It provides you flexibility to declare the structure variable many times.
<br>
If no. of variables are fixed, use 2nd approach. It saves your code to declare variable in main() fuction.<br>
Accessing members of structure <br>

There are two ways to access structure members:<br>

    By . (member or dot operator)<br>
    By -> (structure pointer operator<br>)

Let's see the code to access the id member of p1 variable by . (member) operator.
<br>
    p1.id  
<br>
<h2>Array of Structures</h2>
There can be array of structures in C programming to store many information of different data types. The array of structures is also known as collection of structures.
<br>
Let's see an example of structure with array that stores information of 5 students and prints it.
<br>
#include "stdio.h"  <br>
    #include "string.h"   <br>
    struct student{    <br>
    int rollno;    <br>
    char name[10];    <br>
    };    <br>
    int main(){ <br>    
    int i;    <br>
    struct student st[5]; <br>    
    printf("Enter Records of 5 students");    <br>
    for(i=0;i<5;i++){    <br>
    printf("\nEnter Rollno:");    <br>
    scanf("%d",&st[i].rollno);    <br>
    printf("\nEnter Name:");    <br>
    scanf("%s",&st[i].name);    <br>
    }    <br>
    printf("\nStudent Information List:");    <br>
    for(i=0;i<5;i++){    <br>
    printf("\nRollno:%d, Name:%s",st[i].rollno,st[i].name);    <br>
    }    <br>
       return 0;    <br>
    }    <br>
    <h2>Nested STructures</h2>
    Nested Structure in C  <br>

Nested structure in c language can have another structure as a member. There are two ways to define nested structure in c language:  <br>

    By separate structure <br>
    By Embedded structure <br>

1) Separate structure  <br>

We can create 2 structures, but dependent structure should be used inside the main structure as a member. Let's see the code of nested structure. <br>

    struct Date   <br>
    {   <br>
       int dd;   <br>
       int mm;   <br>
       int yyyy;  <br>   
    };   <br>
    struct Employee   <br>
    {      <br>
       int id;   <br>
       char name[20];   <br>
       struct Date doj;  <br> 
    }emp1;   <br>

As you can see, doj (date of joining) is the variable of type Date. Here doj is used as a member in Employee structure. In this way, we can use Date structure in many structures. <br>
2) Embedded structure  <br>

We can define structure within the structure also. It requires less code than previous way. But it can't be used in many structures.  <br>

    struct Employee   <br>
    {      <br>
       int id;   <br>
       char name[20];   <br>
       struct Date  <br>
        {   <br>
          int dd;   <br>
          int mm;   <br>
          int yyyy;  <br>   
        }doj;   <br>
    }emp1;   <br>

Accessing Nested Structure <br>

We can access the member of nested structure by Outer_Structure.Nested_Structure.member as given below: <br>

    e1.doj.dd   <br>
    e1.doj.mm   <br>
    e1.doj.yyyy  <br>

<a href="cp4c.php"><img src='next1.jpeg' width=10% height=10%></a>
    </body>
</html>
